export class Producto {
  id: number;
  nombre: string;
  stock: number;
}
